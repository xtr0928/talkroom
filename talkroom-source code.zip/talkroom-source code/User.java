public class User{
    private String name;
    private String ip;

    //构造函数
    public User(String name, String ip) {
        this.name = name;
        this.ip = ip;
    }

    //get、set方法
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }
}

