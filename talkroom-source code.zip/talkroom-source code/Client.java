import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.TitledBorder;

public class Client{//客户端

    JFrame frame;
    JList<String> userList;//列表组件
    JTextArea textArea;//文本域
    JTextField textField;
    JTextField txt_port,txt_Ip,txt_name;

    JButton button_start,button_stop,button_send;//连接按钮,断开按钮,发送按钮

    JPanel north,south;//上、下面板
    JScrollPane rightScroll,leftScroll;//左右滚动面板
    JSplitPane centerSplit;//分割面板
    DefaultListModel<String> listModel;//点击事件

    private boolean crossFire = false;

    Socket socket;//套接字
    PrintWriter writer;
    BufferedReader reader;
    MessageThread messageThread;// 负责接收消息的线程
    private Map<String, User> onLineUsers = new HashMap<String, User>();// 所有在线用户集合

    public void send() {//发送方法
        if (!crossFire) {
            JOptionPane.showMessageDialog(frame, "Warning！无法连接服务器", "错误",JOptionPane.ERROR_MESSAGE);
            return;
        }
        String message = textField.getText().trim();
        if (message == null || message.equals("")) {
            JOptionPane.showMessageDialog(frame, "Warning！ 消息不能为空！", "错误",JOptionPane.ERROR_MESSAGE);
            return;
        }
        sendMessage(frame.getTitle() + "@" + "ALL" + "@" + message);
        textField.setText(null);
    }

    public Client() {//创建构造方法
        textArea = new JTextArea();
        textArea.setEditable(false);//设置文本域不可读
        textArea.setForeground(Color.RED);//设置背景颜色位红色

        textField = new JTextField();
        txt_port = new JTextField();//端口号
        txt_Ip = new JTextField();//服务器IP
        txt_name = new JTextField();//用户名

        button_start = new JButton("连接");
        button_stop = new JButton("断开");
        button_send = new JButton("发送");

        listModel = new DefaultListModel<String>();
        userList = new JList<String>(listModel);

        north = new JPanel();
        north.setLayout(new GridLayout(1, 4));//设置布局方式
        north.add(new JLabel("端口"));
        north.add(txt_port);//在JPanel组件中添加端口组件
        north.add(new JLabel("服务器IP:"));
        north.add(txt_Ip);//在JPanel组件中添加IP组件
        north.add(new JLabel("姓名:"));
        north.add(txt_name);//添加文本域组件
        north.add(button_start);//添加按钮组件
        north.add(button_stop);//添加按钮组件
        north.setBorder(new TitledBorder("连接信息"));

        rightScroll = new JScrollPane(textArea);
        rightScroll.setBorder(new TitledBorder("聊天记录区"));

        leftScroll = new JScrollPane(userList);
        leftScroll.setBorder(new TitledBorder("在线用户明细"));//设置组件的边框

        south = new JPanel(new BorderLayout());
        south.add(textField, "Center");
        south.add(button_send, "East");
        south.setBorder(new TitledBorder("写消息"));

        centerSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftScroll,rightScroll);
        centerSplit.setDividerLocation(100);//设置分隔条的相对位置

        frame = new JFrame("客户端");
        frame.add(north, "North");
        frame.add(centerSplit, "Center");
        frame.add(south, "South");
        frame.setSize(750, 350);

        int screen_width = Toolkit.getDefaultToolkit().getScreenSize().width;//获取屏幕的宽度
        int screen_height = Toolkit.getDefaultToolkit().getScreenSize().height;//获取屏幕的高度
        frame.setLocation((screen_width - frame.getWidth()) / 2,(screen_height - frame.getHeight()) / 2);//设置窗口的相对位置
        frame.setVisible(true);//设置组件可见

        // 写消息的文本框中按回车键时事件
        textField.addActionListener(new ActionListener() {//添加监听，监听文本域消息
            public void actionPerformed(ActionEvent arg0) {
                send();
            }
        });

        // 单击发送按钮时事件
        button_send.addActionListener(new ActionListener() {//添加监听，监听发送按钮消息
            public void actionPerformed(ActionEvent e) {
                send();
            }
        });

        // 单击连接按钮时事件
        button_start.addActionListener(new ActionListener() {//添加监听，监听连接按钮消息
            public void actionPerformed(ActionEvent e) {
                int port;
                if (crossFire) {
                    JOptionPane.showMessageDialog(frame, "WARNING!  重复链接","错误", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try {
                    try {
                        port = Integer.parseInt(txt_port.getText().trim());
                    } catch (NumberFormatException e2) {
                        throw new Exception("端口号错误!   端口应为整数!");
                    }
                    String hostIp = txt_Ip.getText().trim();
                    String name = txt_name.getText().trim();
                    if (name.equals("")) {
                        throw new Exception("姓名不能为空!");
                    }

                    if(hostIp.equals(""))
                        throw new Exception("服务器IP不能为空!");

                    boolean flag = connectServer(port, hostIp, name);

                    if (flag == false) {
                        throw new Exception("无连接，或连接失败!");
                    }

                    frame.setTitle(name);
                    JOptionPane.showMessageDialog(frame, "成功连接!");
                } catch (Exception exc) {
                    JOptionPane.showMessageDialog(frame, exc.getMessage(),"错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // 单击断开按钮时事件
        button_stop.addActionListener(new ActionListener() {//添加监听，监听断开按钮消息
            public void actionPerformed(ActionEvent e) {
                if (!crossFire) {
                    JOptionPane.showMessageDialog(frame, "Warning！重复连接","错误", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                try {
                    boolean flag = closeConnection();// 断开连接
                    if (flag == false) {
                        throw new Exception("断开连接发生异常！");
                    }
                    JOptionPane.showMessageDialog(frame, "已断开!");
                } catch (Exception exc) {
                    JOptionPane.showMessageDialog(frame, exc.getMessage(), "错误", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        // 关闭窗口时事件
        frame.addWindowListener(new WindowAdapter() {//添加窗口监听
            public void windowClosing(WindowEvent e) {
                if (crossFire) {
                    closeConnection();//关闭连接
                }
                System.exit(0);//退出程序
            }
        });
    }

    public boolean connectServer(int port, String hostIp, String name) {//连接服务器
        try {
            socket = new Socket(hostIp, port);// 根据端口号和服务器Ip建立连接
            writer = new PrintWriter(socket.getOutputStream());
            reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            sendMessage(name + "@" + socket.getLocalAddress().toString()); //发送客户端用户基本信息(用户名和ip地址)

            messageThread = new MessageThread(reader, textArea);//开启接收消息的线程
            messageThread.start();
            crossFire = true;//已经连接上了
            return true;
        } catch (Exception e) {
            textArea.append("与端口号为：" + port + "    IP地址为：" + hostIp+ "   的服务器连接失败!" + "\r\n");
            crossFire = false;//未连接上
            return false;
        }
    }

    public void sendMessage(String message) {
        writer.println(message);
        writer.flush();
    }

    @SuppressWarnings("deprecation")
    public synchronized boolean closeConnection() {//同步方法
        try {
            sendMessage("CLOSE");//发送断开连接命令给服务器
            messageThread.interrupt();//停止接受消息线程
            reader.close();//释放资源
            writer.close();
            socket.close();
            crossFire=false;
            return true;
        } catch (IOException e1) {
            e1.printStackTrace();
            crossFire = true;
            return false;
        }
    }

    class MessageThread extends Thread {//接收消息线程
        private BufferedReader reader;
        private JTextArea textArea;

        public MessageThread(BufferedReader reader, JTextArea textArea) {//创建线程的构造方法
            this.reader = reader;
            this.textArea = textArea;
        }

        public synchronized void closeCon() throws Exception {//同步方法
            listModel.removeAllElements();// 清空用户列表
            reader.close();//关闭连接释放资源
            writer.close();
            socket.close();
            crossFire = false;//修改状态为断开
        }

        @SuppressWarnings("unlikely-arg-type")
        public void run() {
            String message = "";
            while (true) {
                try {
                    message = reader.readLine();
                    StringTokenizer stringTokenizer = new StringTokenizer(message, "/@");//分解字符串
                    String command = stringTokenizer.nextToken();//返回下一个
                    if (command.equals("CLOSE")){// 服务器已关闭命令
                        textArea.append("服务器已关闭!\r\n");
                        closeCon();//关闭连接
                        return;//结束线程
                    } else if (command.equals("ADD")) {//有用户上线更新在线列表
                        String username;
                        String userIp;
                        if ((username = stringTokenizer.nextToken()) != null&& (userIp = stringTokenizer.nextToken()) != null) {
                            User user = new User(username, userIp);
                            onLineUsers.put(username, user);
                            listModel.addElement(username);
                        }
                    } else if (command.equals("DELETE")) {//有用户下线更新在线列表
                        String username = stringTokenizer.nextToken();
                        User user = (User) onLineUsers.get(username);
                        onLineUsers.remove(user);//删除下线用户名及ip
                        listModel.removeElement(username);//删除在线列表中用户名
                    } else if (command.equals("USERLIST")) {// 加载在线用户列表
                        int size = Integer.parseInt(stringTokenizer.nextToken());//使用下一个参数指定的基数，将字符串参数解析为有符号的整数
                        String username = null;
                        String userIp = null;
                        for (int i = 0; i < size; i++) {
                            username = stringTokenizer.nextToken();
                            userIp = stringTokenizer.nextToken();
                            User user = new User(username, userIp);
                            onLineUsers.put(username, user);//更新在线用户
                            listModel.addElement(username);//添加用户名
                        }
                    } else if (command.equals("MAX")) {//人数达到上限
                        textArea.append(stringTokenizer.nextToken()+ stringTokenizer.nextToken() + "\r\n");//将用户名及用户IP添加到文本域，提示用户达到上限
                        closeCon();//关闭连接
                        JOptionPane.showMessageDialog(frame, "服务器缓冲区已满！", "错误",JOptionPane.ERROR_MESSAGE);//消息对话框
                        return;// 结束线程
                    } else {//消息
                        textArea.append(message + "\r\n");
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public static void main(String[] args) {
        new Client();
    }
}
